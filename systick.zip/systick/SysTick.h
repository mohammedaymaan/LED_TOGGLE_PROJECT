#ifndef SYSTICK_H
#define SYSTICK_H

/**********************************************************************************************************************
 * INCLUDES
 *********************************************************************************************************************/
#include "SysTick_Types.h"

/**********************************************************************************************************************
 *  GLOBAL CONSTANT MACROS
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *  GLOBAL FUNCTION MACROS
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *  GLOBAL DATA TYPES AND STRUCTURES
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *  GLOBAL DATA PROTOTYPES
 *********************************************************************************************************************/

 
/**********************************************************************************************************************
 *  GLOBAL FUNCTION PROTOTYPES
 
*********************************************************************************************************************/
SysTick_returnCodes Systick_Init(void);								//set timer value
SysTick_returnCodes Systick_SetTimerMS(uint32 timerValue);			//set timer in milli seconds value
SysTick_returnCodes Systick_SetTimerReg(uint32 Systick_timerRegisterValue);			//set timer in hexavalue timer
uint32 Systick_GetTimerValue(void);									//get_timer value
SysTick_returnCodes Systick_IsTimerFinished(void);					//checks if timer finished 
SysTick_returnCodes Systick_delayMS(uint32 milliSeconds);			//makes a delay by desired milliseconds
SysTick_returnCodes Systick_SystickReturnCodesEnableSystickInterrupt(void);     //Enables Systick timer interrupt
SysTick_returnCodes Systick_SystickReturnCodesDisableSystickInterrupt(void);    //Disables Systick timer interrupt
void SysTick_setCallBack(void (*ptr2Fun)(void));
void SysTick_Handler(void);

#endif  /* FILE_NAME_H */
